# Copy input to output
# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# project :
# Author :Xiaochao
#############################################################

# 将算法得到的输出结果的数据类型DataFrame转换str类型
A0 = input_table[['timestamp']]
# 将DataFrame类型转换为ndrray类型
times = A0.values
# 将ndarray类型转换为list类型
dt = times.tolist()
# 将list转换为元组类型,然后将元组的[]去掉，转换为可以直接循环的list
dt = tuple(dt)
s = []
for k in dt:
    s.append(str(k[0]))
dt = s

# 将算法得到的输出结果的数据类型DataFrame转换varchar类型
A6 = input_table[['Prediction (value)']]
# 将DataFrame类型转换为ndrray类型
times = A6.values
# 将ndarray类型转换为list类型
predict = times.tolist()
# 将list转换为元组类型,然后将元组的[]去掉，转换为可以直接循环的list
predict = tuple(predict)
s = []
for k in predict:
    s.append(str(k[0]))
predict = s

# 将算法得到的输出结果的数据类型DataFrame转换str类型
A2 = input_table[['value']]
# 将DataFrame类型转换为ndrray类型
shirms = A2.values
# 将ndarray类型转换为list类型
fftrms = shirms.tolist()
# 将list转换为元组类型,然后将元组的[]去掉，转换为可以直接循环的list
fftrms = tuple(fftrms)
s = []
for q in fftrms:
    s.append(float(q[0]))
fftrms = s

# Python连接MySql数据库 #
import pymysql

# 打开数据库连接（ip/数据库用户名/登录密码/数据库名）
# 查询数据库
db = pymysql.connect("192.168.0.127", "root", "112233", "cdids")
# 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

# 从数据库中读取原始的rms
sql = 'select rms from motor1_regress_result'
try:
    # 执行SQL语句
    cursor.execute(sql)
    # 获取所有记录列表
    results = cursor.fetchall()
except:
    print('Error: unable to rms data')
# 判断原表格中是否有数据，如果有则执行下面的操作，如果没有，则直接赋值为空
if ('results' in locals().keys()):
    # 将tuple 类型转换为字符串类型,注意这个字符串是表格中所有的type
    rms = " ".join('%s' % id for id in results)
else:
    rms = []

# 以空格分割为数组
rmstype = rms.split()
# 注意这里的rms是str类型,N 为数据库中表中数据的个数
N = len(rmstype)
# 如果表中数据N大于4000，说明已经写入了两小时数据，删除前3600个数据，(写入最近1个小时的数据)；如果表中数据N小于4000，(直接写入数据)
# 其中括号内的操作不需处理
if N > 5000:
    # 从数据中读取前3600条数据
    sql = 'delete from motor1_regress_result WHERE 1 = 1 order by timestamp limit 3550'
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 提交修改
        db.commit()
    except:
        # 发生错误时回滚
        db.rollback()

    # 将新写入的数据实时到数据库
    start = 0
    end = len(fftrms)
    for i in range(start, end):
        # 转换为标准时间格式
        # timestamps = datetime.datetime.strptime(timestamp, "%d/%m/%Y %H:%M:%S")
        timestamps = dt[i]

        rms1 = fftrms[i]
        rms1 = float(rms1)

        if predict[i] == 'nan':
            # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
            cursor.execute(
                "INSERT INTO motor1_regress_result(timestamp,rms) VALUES('%s','%f')" % (timestamps, rms1))
        else:
            predict1 = predict[i]
            predict1 = float(predict1)
            # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
            cursor.execute(
                "INSERT INTO motor1_regress_result(timestamp,rms,predict) VALUES('%s','%f','%f')" % (
                timestamps, rms1, predict1))
    # 将数据上传到数据库中
    db.commit()
else:
    # 将新写入的数据实时到数据库
    start = 0
    end = len(fftrms)
    for i in range(start, end):
        # 转换为标准时间格式
        # timestamps = datetime.datetime.strptime(timestamp, "%d/%m/%Y %H:%M:%S")
        timestamps = dt[i]

        rms1 = fftrms[i]
        rms1 = float(rms1)

        if predict[i] == 'nan':
            # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
            cursor.execute(
                "INSERT INTO motor1_regress_result(timestamp,rms) VALUES('%s','%f')" % (timestamps, rms1))
        else:
            predict1 = predict[i]
            predict1 = float(predict1)
            # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
            cursor.execute(
                "INSERT INTO motor1_regress_result(timestamp,rms,predict) VALUES('%s','%f','%f')" % (
                timestamps, rms1, predict1))
    # 将数据上传到数据库中
    db.commit()


