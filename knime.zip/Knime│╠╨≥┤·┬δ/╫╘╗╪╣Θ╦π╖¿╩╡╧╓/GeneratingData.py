#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

# 实现功能：
# 1、通过for循环写入到数据库中；
# 2、1s更新一次，然后将更新的值在Navicat中相当于插入显示出来；
# 3、数据可在Navicat中1秒输出1次，刷新后跳出新数据
# 4、显示输出第几次的数据，在表已经存在的情况下，实现插入功能


# Python连接MySql数据库 #
import pymysql
import datetime
import time

# 打开数据库连接（ip/数据库用户名/登录密码/数据库名）

db = pymysql.connect("localhost", "root", "123", "test")
# 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

# 使用 execute()  方法执行 SQL 查询
cursor.execute("SELECT VERSION()")
# 使用 fetchone() 方法获取单条数据.
data = cursor.fetchone()
print("Database version : %s " % data)
db.close()
# 关闭数据库连接


#  数据库插入操作 #
db = pymysql.connect("localhost", "root", "123", "test")
# 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

sql = '''create table Line_motor1(
        timestamp varchar(25) primary key not null,
        value double(16,8))'''
cursor.execute(sql)

# 从txt中读取数据，text是一个字符串

# 导入 random(随机数) 模块
import random

# 将读到的数据读入到数据库中，通过for循环实现
for i in range(55500):
    # 生成0到1的随机数
    a = random.random()
    print('第', i + 1, '次的数据是: ', a)

    # 获取当前时刻的时间
    dt = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print('第' ,i+1,'次产生的Timestamp是: ', dt)
    # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型
    cursor.execute("INSERT INTO Line_motor1(timestamp,value) VALUES('%s','%f')" % (dt,a))
    # 休眠一秒钟，每一秒钟读取一次
    time.sleep(1)
    i = i + 1
    # 将数据上传到数据库中
    db.commit()

# 关闭数据库连接
print("Congratulations, all the data has been imported!")
db.close()





