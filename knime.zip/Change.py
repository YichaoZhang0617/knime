# 自己循环实现每次读取300条数据，每读取一次停止10秒钟，30秒钟后检查一次要不要更新
import numpy as np
from sklearn import neighbors
import pandas as pd
from pandas import DataFrame
import math

# 第一部分：将所有标签值的预测转化为文字格式
input_table = pd.read_csv('mfs_bearing1.csv')
#input_table 是 DataFrame类型
#读取第五列
A1 = input_table[['Prediction (class)']]
# 将DataFrame类型转换为ndrray类型
dataset = A1.values
# 将标签值转换成文字的形式，matrix[0]---matrix[len(dataset-1)]
matrix=[0]*(len(dataset))

j = 0
k = [0]*5
# i是ndarray类型
for i in dataset:
    if i == np.array(1):
       matrix[j] = "滚珠故障"
       k[0] = k[0] + 1
    elif i == np.array(2):
       matrix[j] = "混合故障"
       k[1] = k[1] + 1
    elif i == np.array(3):
       matrix[j] = "外圈故障"
       k[2] = k[2] + 1
    elif i == np.array(4):
       matrix[j] = "内圈故障"
       k[3] = k[3] + 1
    else:
       matrix[j] = "正常轴承"
    j = j+1
lead = k.index(max(k))
# 其中k表示每种故障数量的数组，并获取最大值的下标,实际上没用

# 为了方便查询，写一个元组
yuanzu = {'滚珠故障':0,'混合故障':1,'外圈故障':2,'内圈故障':3,'正常轴承':4}

# 第二部分：连接数据库，并实现数据库数据的刷新
# Python连接MySql数据库 #
import pymysql
import datetime
import time

# 打开数据库连接（ip/数据库用户名/登录密码/数据库名）
# 查询数据库
db = pymysql.connect("localhost", "root", "123", "test")
# 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

A2 = input_table[['value']]
# 将DataFrame类型转换为ndrray类型
shirms = A2.values
# 将ndarray类型转换为list类型
rms = shirms.tolist()
# 将list转换为元组类型,然后将元组的[]去掉，转换为可以直接循环的list
rms = tuple(rms)
s = []
for q in rms:
    s.append(float(q[0]))
rms = s

A3 = input_table[['value1']]
# 将DataFrame类型转换为ndrray类型
pinrms = A3.values
# 将ndarray类型转换为list类型
fftrms = pinrms.tolist()
# 将list转换为元组类型,然后将元组的[]去掉，转换为可以直接循环的list
fftrms = tuple(fftrms)
s = []
for m in fftrms:
    s.append(float(m[0]))
fftrms = s

# 一组读取300个数据，分几批读取
size = len(matrix)/300
bathsize = math.ceil(size)
lengths = bathsize+1
#####################################################

for n in range(1,lengths):
    start = 300 * (n - 1)
    end = start + 300
    for i in range(start,end):
        # 获取当前时刻的时间
        dt = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # print('此时产生的Timestamp是: ', dt)
        rms1 = rms[i]
        fftrms1 = fftrms[i]
        matrix1 = matrix[i]
        # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
        cursor.execute("INSERT INTO mfs_bear1_dtanalysis_result(timestamp,rms,fftrms,predict) VALUES('%s','%f','%f','%s')" % (dt,rms1,fftrms1,matrix1))
        # 将数据上传到数据库中
        db.commit()
    # 休眠十秒钟后删除所有数据
    time.sleep(10)
    sql = "DELETE FROM mfs_bear1_dtanalysis_result WHERE rms > '%f'" % (0)
    try:
       # 执行SQL语句
       cursor.execute(sql)
       # 提交修改
       db.commit()
    except:
       # 发生错误时回滚
       db.rollback()
#####################################################
# 关闭数据库连接
print("Congratulations, all the data has been imported!")
db.close()

# 第三部分： 在连接数据库的情况下进行数据的添加操作，在刷新一次时统计哪种预测的故障最多，然后将最多的输出；
# 如果下次刷新没有变化，则不新增数据，如果1小时后仍没有变化则要新增一个原情况，只需要改变时间戳就可以

# 打开数据库连接（ip/数据库用户名/登录密码/数据库名）
# 查询数据库
db = pymysql.connect("localhost", "root", "123", "test")
# 使用 cursor() 方法创建一个游标对象 cursor
cursor = db.cursor()

# 用p参与循环，表示参与的组数
o = 0
leads = [0]*bathsize
p =1
# 只要是range就是从p=0 到 bathsize -1
for p in range(1,lengths):   # p取1到5
    o = 300 * (p-1) +1
    for o in range(o,o+300):    # o是从1开始取值
        # b 表示数目数组
        u = o - 1
        b = [0] * 4
        if   matrix[u] == "滚珠故障":
            b[0] = b[0] + 1
        elif matrix[u] == "混合故障":
            b[1] = b[1] + 1
        elif matrix[u] == "外圈故障":
            b[2] = b[2] + 1
        elif matrix[u] == "内圈故障":
            b[3] = b[3] + 1
        else:
            pass
    leads[p-1] = b.index(max(b))
    # 其中leads[0]表示第一组最大值的下标，第一次运行时leads[p-2]=0
    # print(leads[p-2] != leads[p-1])
    # print(p%3 == 0)
    # 通过组数来确定是不是达到1小时，如果十秒钟刷新一次的话，3组之后（也就是30秒之后）一定会自动输出一次
    if (leads[p-2] != leads[p-1]) or (p % 3 == 0) :
        # 获取当前时刻的时间
        dt = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # print('此时产生的Timestamp是: ', dt)
        device = '1号轴承'
        status = '异常'
        # 找到元组中的key值
        store = leads[p-1]
        guzhangtype = list(yuanzu.keys())[list(yuanzu.values()).index(store)]
        # 注意这里的字符串拼接，'+ str(s[0]) +'表示告诉Navicat这是一个字符串型'''
        cursor.execute("INSERT INTO mfs_fault(timestamp,device,status,type) VALUES('%s','%s','%s','%s')" % (dt,device,status,guzhangtype))
        # 将数据上传到数据库中
        db.commit()
    else:
        pass
    # 10秒钟后如果最大值与前一个最大值相同不再输出到数据库
    time.sleep(10)

# 关闭数据库连接
print("Congratulations, all the data has been imported!")
db.close()



